// Graphs.js
const Graphs = () => <div>Graphs Data</div>;
export default Graphs;