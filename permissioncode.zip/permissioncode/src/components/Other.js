
// Other.js
const Other = () => <div>Other Information</div>;
export default Other;