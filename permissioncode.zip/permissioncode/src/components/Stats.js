// Stats.js
const Stats = () => <div>Stats Data</div>;
export default Stats;