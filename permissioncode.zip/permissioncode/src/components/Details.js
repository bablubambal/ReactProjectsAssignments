
// Details.js
const Details = () => <div>Details Data</div>;
export default Details;