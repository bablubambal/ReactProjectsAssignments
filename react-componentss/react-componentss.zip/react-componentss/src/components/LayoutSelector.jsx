const LayoutSelector = ({ onSelect }) => {
    return (
     <div style={{width:"30%"}} className="m-3">
       <select className="form-control" onChange={e => onSelect(e.target.value)}>
        <option value="textTopImageBottom">Text Top, Image Bottom</option>
        <option value="textLeftImageRight">Text Left, Image Right</option>
        <option value="textBottomImagetop">Text Bottom, Image TOP</option>
        <option value="textRightImageLeft">Text Right, Image Left</option>
      </select>
     </div>
    );
  };


  export default LayoutSelector;