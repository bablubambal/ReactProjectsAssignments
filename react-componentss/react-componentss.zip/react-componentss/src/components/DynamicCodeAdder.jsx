// import React, { useState } from 'react';
// import DynamicComponent from './DynamicComponent';

// const DynamicComponentAdder = () => {
//   // ... useState and functions you already defined
//   const [components, setComponents] = useState([]);
//   const addComponent = () => {
//     const newComponent = {
//       id: Math.random(),
//       layout: 'textTopImageBottom', // default layout
//       heading: 'Editable Heading',
//       paragraph: 'Editable paragraph content...',
//       imageSrc: 'https://via.placeholder.com/250'
//     };
//     setComponents([...components, newComponent]);
//   };

//   const anotherComponent = () => {
//     const newComponent = {
//       id: Math.random(),
//       // layout: 'textTopImageBottom', // default layout
//       heading: 'Editable Heading',
//       // paragraph: 'Editable paragraph content...',
//       // imageSrc: 'https://via.placeholder.com/250'
//     };
//     setComponents([...components, newComponent]);
//   };

//   const updateComponent = (id, updatedData) => {
//     setComponents(components.map(comp => comp.id === id ? updatedData : comp));
//   };

//   const removeComponent = (id) => {
//     setComponents(components.filter(comp => comp.id !== id));
//   };


//   return (
//     <div className="container mt-3">
//       {components.map((componentData) => (
//         <DynamicComponent
//           key={componentData.id}
//           data={componentData}
//           updateComponent={updateComponent}
//           removeComponent={removeComponent}
//         />
//       ))}
//       <button className=" m-4 btn btn-primary" onClick={addComponent}>Add Component</button>
//       <button className=" m-4 btn btn-primary" onClick={anotherComponent}>Another Componentttt Component</button>
      
//     </div>
//   );
// };

// export default DynamicComponentAdder;


// DynamicComponentAdder.js
// import React, { useState } from 'react';
// import DynamicComponent from './DynamicComponent';
// import EditableField from './EditableField';

// const DynamicComponentAdder = () => {
//   const [components, setComponents] = useState([]);
//   const [componentType, setComponentType] = useState('layout'); // default to 'layout'

//   const addComponent = () => {
//     let newComponent;
//     if (componentType === 'layout') {
//       newComponent = {
//         id: Math.random(),
//         type: 'layout',
//         layout: 'textTopImageBottom', // default layout
//         heading: 'Editable Heading',
//         paragraph: 'Editable paragraph content...',
//         imageSrc: 'https://via.placeholder.com/450'
//       };
//     } 
//     else if (componentType === 'textField') {
//       newComponent = {
//         id: Math.random(),
//         type: 'textField',
//         text: 'Editable text...'
//       };
//     }
//     setComponents([...components, newComponent]);
//   };

//   const updateComponent = (id, updatedData) => {
//     setComponents(components.map(comp => comp.id === id ? { ...comp, ...updatedData } : comp));
//   };

//   const removeComponent = (id) => {
//     setComponents(components.filter(comp => comp.id !== id));
//   };

//   return (
//     <div className="container mt-3">
//       <div className="mb-3 ">
//         <select className="form-select form-control " onChange={e =>{ 
//           setComponentType(e.target.value)
//           if(e.target.value != "default"){
//           addComponent()
          
        
//         }
//         }}>
//           <option value="default"> Component</option>
//           <option value="layout">Add Layout</option>
//           <option value="textField">Add Text Field</option>
//         </select>
//         {/* <button className="btn btn-primary mt-2" onClick={addComponent}>Add Component</button> */}
//       </div>
//       {components?.map(componentData => {
//         if (componentData.type === 'layout') {
//           return (
//             <DynamicComponent
//               key={componentData.id}
//               data={componentData}
//               updateComponent={updateComponent}
//               removeComponent={removeComponent}
//             />
//           );
//         } else if (componentData.type === 'textField') {
//           return (
//             <div key={componentData.id} className="mb-3">
//               <EditableField
//                 value={componentData.text}
//                 onValueChange={text => updateComponent(componentData.id, { text })}
//               />
//               {/* <button className="btn btn-danger mt-2" onClick={() => removeComponent(componentData.id)}>Remove</button> */}
//             </div>
//           );
//         }
//         return null;
//       })}
//     </div>
//   );
// };

// export default DynamicComponentAdder;



// DynamicComponentAdder.js
import React, { useState } from 'react';
import DynamicComponent from './DynamicComponent';
import EditableField from './EditableField';

const DynamicComponentAdder = () => {
  const [components, setComponents] = useState([]);

  const addComponent = (type) => {
    let newComponent;
    if (type === 'layout') {
      newComponent = {
        id: Math.random(),
        type: 'layout',
        layout: 'textTopImageBottom', // default layout
        heading: 'Editable Heading',
        paragraph: 'Editable paragraph content...',
        imageSrc: 'https://via.placeholder.com/350'
      };
    } else if (type === 'textField') {
      newComponent = {
        id: Math.random(),
        type: 'textField',
        text: 'Editable text...'
      };
    }

    // Add the new component if type is selected
    if (type) {
      setComponents([...components, newComponent]);
    }
  };

  const updateComponent = (id, updatedData) => {
    setComponents(components.map(comp => comp.id === id ? { ...comp, ...updatedData } : comp));
  };

  const removeComponent = (id) => {
    setComponents(components.filter(comp => comp.id !== id));
  };

  return (
    <div className="container mt-3">
      <div className="mb-3">
        <select className="form-select" onChange={(e) => addComponent(e.target.value)}>
          <option value="">Select Component to Add</option>
          <option value="layout">Layout</option>
          <option value="textField">Text Field</option>
        </select>
      </div>
      {components.map((componentData) => {
        if (componentData.type === 'layout') {
          return (
            <DynamicComponent
              key={componentData.id}
              data={componentData}
              updateComponent={updateComponent}
              removeComponent={removeComponent}
            />
          );
        } else if (componentData.type === 'textField') {
          return (
            <div key={componentData.id} className="mb-3">
              <EditableField
                value={componentData.text}
                onValueChange={(text) => updateComponent(componentData.id, { text })}
              />
              {/* <button className="btn btn-danger mt-2" onClick={() => removeComponent(componentData.id)}>Remove</button> */}
            </div>
          );
        }
        return null;
      })}
    </div>
  );
};

export default DynamicComponentAdder;


