import logo from './logo.svg';
import './App.css';
import {LayoutProvider } from './components/LayoutContext'
import CardsContainer from './components/CardsContainer'
import DynamicCodeAdder from './components/DynamicCodeAdder'
function App() {
  return (
    <div >
      
<DynamicCodeAdder/>

      <LayoutProvider>
      <div className='container'>
      <h2 className="mx-3 my-4">Cards Heading</h2>
        <CardsContainer />  

      </div>
    </LayoutProvider>

    
    </div>
  );
}

export default App;
